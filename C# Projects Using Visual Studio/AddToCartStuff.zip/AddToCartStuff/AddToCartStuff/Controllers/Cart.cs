﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AddToCartStuff.Models;

namespace AddToCartStuff.Controllers
{
    public class Cart : Controller
    {
        [HttpPost]
        public ActionResult addcart()
        {
            return View();
        }

        public ActionResult Index()
        {
            List<Item> list = new List<Item>();
            Item i = new Item();
            list = i.GetItem();

            return View (list);
        }
    }
}
