﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AddToCartStuff.Models;

namespace AddToCartStuff.Controllers
{
    public class CartController : Controller
    {
        public ActionResult Dummy()
        {
            List<Item> car1 = (List<Item>)Session["cart"];
            return View(car1);
        }

        [HttpPost]
        public ActionResult addcart(FormCollection form)
        {
            if(Session["cart"] == null)
            {
                List<Item> car1 = new List<Item>();
                Item ite = new Item();
                ite.FID = int.Parse(form["id"]);
                ite.FoodName = form["name"].ToString();
                ite.Description = form["desc"].ToString();
                ite.SellingPrice = float.Parse(form["sell"]);
                car1.Add(ite);
                Session["cart"] = car1;
            }
            else
            {
                List<Item> car1 = (List<Item>)Session["cart"];
                Item ite = new Item();
                ite.FID = int.Parse(form["id"]);
                ite.FoodName = form["name"].ToString();
                ite.Description = form["desc"].ToString();
                ite.SellingPrice = float.Parse(form["sell"]);
                car1.Add(ite);
                Session["cart"] = car1;
            }


            return RedirectToAction("Index");
        }

        public ActionResult Index()
        {
            List<Item> list = new List<Item>();
            Item i = new Item();
            list = i.GetItem();

            return View(list);
        }
    }
}
