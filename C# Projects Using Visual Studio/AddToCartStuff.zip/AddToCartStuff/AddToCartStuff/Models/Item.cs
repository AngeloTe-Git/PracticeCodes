﻿using System;
using System.Collections.Generic;

namespace AddToCartStuff.Models
{
    public class Item
    {
        public int FID { get; set; }

        public string FoodName { get; set; }

        public string Description { get; set; }

        public float SellingPrice { get; set; }

        public List<Item> GetItem ()
        {
            List<Item> item = new List<Item>();
            Item Ite = new Item();

            Ite.FID = 1;
            Ite.FoodName = "Spagehtti";
            Ite.Description = "Red sauce Pasta";
            Ite.SellingPrice = 60;
            item.Add(Ite);

            Item fte = new Item();
            fte.FID = 2;
            fte.FoodName = "Good Food";
            fte.Description = "Some Random As Food";
            fte.SellingPrice = 70;
            item.Add(fte);

            Item gte = new Item();
            gte.FID = 3;
            gte.FoodName = "Steak n' Rice";
            gte.Description = "Some Good Ol' Steak";
            gte.SellingPrice = 120;
            item.Add(gte);

            return item;
        }

    }
}
