﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using FacultyCRUD.Models;

namespace FacultyCRUD.Controllers
{
    public class FacultyController : Controller
    {
        // GET: Faculty
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(FormCollection obj)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-CL737;DATABASE=ISPROG3ofsomeone;UID=sa;PWD=benilde");
            con.Open();
            SqlCommand com = new SqlCommand("INSERT INTO Faculty VALUES(@a,@b,@c,@d);",con);
            com.Parameters.AddWithValue("@a",obj["firstname"].ToString());
            com.Parameters.AddWithValue("@b",obj["lastname"].ToString());
            com.Parameters.AddWithValue("@c",obj["department"].ToString());
            com.Parameters.AddWithValue("@d",obj["email"].ToString());
            com.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("GetRecord");
        }
        public ActionResult GetRecord(Faculty obj)
        {
            List<Faculty> f = new List<Faculty>();
            f = obj.GetAll();

            return View(f);
        }

        [HttpPost]
        public ActionResult Delete(Faculty obj)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-CL737;DATABASE=ISPROG3ofsomeone;UID=sa;PWD=benilde");
            con.Open();
            SqlCommand com = new SqlCommand("DELETE FROM Faculty WHERE FacultyID = @A", con);
            com.Parameters.AddWithValue("@a", obj.FacultyID);

            com.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("GetRecord");
        }

        [HttpGet]
        public ActionResult Edit(Faculty obj)
        {
            SqlConnection con = new SqlConnection(
                "Server=taft-cl737;Database=ISPROG3ofsomeone;" +
                "uid=sa;pwd=benilde");
            con.Open();
            SqlCommand com = new SqlCommand(
                "SELECT * FROM FACULTY WHERE FacultyID=@fid", con);
            com.Parameters.AddWithValue("@fid", obj.FacultyID);
            SqlDataReader dr = com.ExecuteReader();
            Faculty f = new Faculty();
            if (dr.Read() == true)
            {
                f.FacultyID = (int)dr["FacultyID"];
                f.Firstname = dr[1].ToString();
                f.Lastname = dr[2].ToString();
                f.Department = dr[3].ToString();
                f.EmailAddress = dr[4].ToString();
            }
            con.Close();

            return View(f);
        }

        [HttpPost]
        public ActionResult Change(FormCollection obj)
        { 
            SqlConnection con = new SqlConnection(
                "SERVER=taft-cl737;DATABASE=ISPROG3ofsomeone;" +
                "UID=sa;PWD=benilde");
            con.Open();

            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "UPDATE Faculty SET Lastname = @a," +
                "Firstname = @b, Department = @c, EmailAddress=@d WHERE FacultyID = @e ";
            com.Parameters.AddWithValue("@a", obj["lastname"].ToString());
            com.Parameters.AddWithValue("@b", obj["firstname"].ToString());
            com.Parameters.AddWithValue("@c", obj["department"].ToString());
            com.Parameters.AddWithValue("@d", obj["email"].ToString());
            com.Parameters.AddWithValue("@e", obj["facultyid"]);
            //ra represents the no. of rows affected in the table
            int ra = com.ExecuteNonQuery();

            con.Close();
            return RedirectToAction("GetRecord");
        }
        public ActionResult Index()
        {
            return View();
        }
    }
}