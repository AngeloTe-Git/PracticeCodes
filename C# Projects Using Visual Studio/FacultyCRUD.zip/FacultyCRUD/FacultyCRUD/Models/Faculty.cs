﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace FacultyCRUD.Models
{
    public class Faculty
    {
        public int FacultyID { get; set; }

        public string Lastname { get; set; }

        public string Firstname { get; set; }

        public string Department { get; set; }

        public string EmailAddress { get; set; }

        public List<Faculty> GetAll()
        {
            List<Faculty> list = new List<Faculty>();
            SqlConnection con = new SqlConnection("SERVER=TAFT-CL737;DATABASE=ISPROG3ofsomeone;UID=sa;PWD=benilde");
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Faculty",con);
            com.ExecuteNonQuery();
            SqlDataReader dr = com.ExecuteReader();

            while(dr.Read()==true)
            {
                Faculty obj = new Faculty();
                obj.FacultyID = (int)dr["FacultyID"];
                obj.Lastname = dr["Lastname"].ToString();
                obj.Firstname = dr["Firstname"].ToString();
                obj.Department = dr["Department"].ToString();
                obj.EmailAddress = dr["EmailAddress"].ToString();
                list.Add(obj);
            }

            
            con.Close();
            return list;
        }

    }
}