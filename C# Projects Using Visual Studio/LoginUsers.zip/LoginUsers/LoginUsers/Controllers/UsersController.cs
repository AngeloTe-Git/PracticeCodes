﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using LoginUsers.Models;

namespace LoginUsers.Controllers
{
    public class UsersController : Controller
    {
        // GET: Users
        public ActionResult resetpassword(FormCollection form)
        {
            if(!(Session["UserLevel"].ToString().Equals("Admin")|| Session["UserLevel"].ToString().Equals("Client")))
            {
                return RedirectToAction("mainpage");
            }
            User u = new User();
            u.Username = form["username"].ToString();
            u.Userlevel = form["userlevel"].ToString();

            return View(u);
        }
        [HttpPost]
        public ActionResult resetpassword(FormCollection form)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
               "UID=sa;PWD=benilde;");
            con.Open();
            SqlCommand com = new SqlCommand("UPDATE Users SET Password = @a WHERE Username = @b", con);
            com.Parameters.AddWithValue("@a", form["password"]);
            com.Parameters.AddWithValue("@b", form["username"]);
            com.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("listusers");
        }
        [HttpPost]
        public ActionResult changelevel(FormCollection form)
        {
            string level = form["userlevel"].ToString();
            if(level.Equals("Admin"))
            {
                SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
               "UID=sa;PWD=benilde;");
                con.Open();
                SqlCommand com = new SqlCommand("UPDATE Users SET UserLevel = 'Client' WHERE Username = @a", con);
                com.Parameters.AddWithValue("@a", form["username"]);
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
               "UID=sa;PWD=benilde;");
                con.Open();
                SqlCommand com = new SqlCommand("UPDATE Users SET UserLevel = 'Admin' WHERE Username = @a", con);
                com.Parameters.AddWithValue("@a", form["username"]);
                com.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("listusers");
        }
        [HttpPost]
        public ActionResult delete(FormCollection form)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
                "UID=sa;PWD=benilde;");
            con.Open();
            SqlCommand com = new SqlCommand("DELETE FROM Users WHERE Username = @a", con);
            com.Parameters.AddWithValue("@a", form["username"]);
            com.ExecuteNonQuery();
            return RedirectToAction("listusers");
        }
        public ActionResult listusers()
        {
            if (Session["UserLevel"] == null)
            {
                return RedirectToAction("Index");
            }
            if (!(Session["UserLevel"].ToString().Equals("Admin") || Session["UserLevel"].ToString().Equals("Client")))
            {
                return RedirectToAction("Index");
            }
            User u = new User();
            List<User> list = new List<User>();
            list = u.GetAll();

            return View(list);
        }
        public ActionResult mainpage()
        {
            if (Session["UserLevel"] == null)
            {
                return RedirectToAction("Index");
            }
            if (!(Session["UserLevel"].ToString().Equals("Admin")|| Session["UserLevel"].ToString().Equals("Client")))
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult adduser()
        {
            if(Session["UserLevel"] == null)
            {
                return RedirectToAction("Index");
            }
            if(!Session["UserLevel"].ToString().Equals("Admin"))
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        [HttpPost]
        public ActionResult adduser(FormCollection form)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
                "UID=sa;PWD=benilde;");
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users WHERE Username = @a", con);
            com.Parameters.AddWithValue("@a", form["username"]);
            SqlDataReader dr = com.ExecuteReader();
            if (dr.Read() == true)
            {
                return View("UsernameExist");
            }
            dr.Close();


            SqlCommand com2 = new SqlCommand("INSERT INTO Users VALUES(@a,@b,@c,@d)", con);
            com2.Parameters.AddWithValue("@a", form["username"].ToString());
            com2.Parameters.AddWithValue("@b", form["password"].ToString());
            com2.Parameters.AddWithValue("@c", form["userlevel"].ToString());
            com2.Parameters.AddWithValue("@d", 0);
            com2.ExecuteNonQuery();
            con.Close();
            return View();
        }

        [HttpPost]
        public ActionResult logout()
        {
            Session.Abandon();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult login(FormCollection obj)
        {
            SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;" +
                "UID=sa;PWD=benilde;");
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM USERS WHERE Username = @a AND Password = @b", con);
            com.Parameters.AddWithValue("@a",obj["username"]);
            com.Parameters.AddWithValue("@b", obj["password"]);
            SqlDataReader dr = com.ExecuteReader();
            if(dr.Read()==true)
            {
                Session["Username"] = dr["Username"];
                Session["UserLevel"] = dr["UserLevel"];
            }
            dr.Close();
            con.Close();
            return View("Index");
        }
        public ActionResult Index()
        {
            if (Session["UserLevel"] == null)
            {
                Session["UserLevel"] = "";
            }
            if (Session["UserLevel"].ToString().Equals("Admin") || Session["UserLevel"].ToString().Equals("Client"))
            {
                return RedirectToAction("mainpage");
            }
            
            return View();
        }
    }
}