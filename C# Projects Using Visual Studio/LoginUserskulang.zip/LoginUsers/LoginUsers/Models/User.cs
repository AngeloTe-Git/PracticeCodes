﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace LoginUsers.Models
{
    public class User
    {
        public int UserID { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string Userlevel { get; set; }
        public Decimal TotalPurchase { get; set; }


        public List<User> GetAll()
        {

            SqlConnection con = new SqlConnection("SERVER=TAFT-IS112;DATABASE=Final_Proj;UID=sa;PWD=benilde;");
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users", con);
            SqlDataReader dr = com.ExecuteReader();

            List<User> list = new List<User>();

            while(dr.Read() == true)
                {

                User u = new User();

                u.Username = dr["Username"].ToString();

                u.Userlevel = dr["UserLevel"].ToString();

                list.Add(u);
            }

            dr.Close();
            con.Close();

            return list;
        }
    }
}