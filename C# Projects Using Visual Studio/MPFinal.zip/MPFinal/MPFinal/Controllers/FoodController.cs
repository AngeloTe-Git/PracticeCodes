﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using MPFinal.Models;

namespace MPFinal.Controllers
{
    public class FoodController : Controller
    {

        public string constring = "server=DESKTOP-0E62KFU\\SQLEXPRESS;database=FINALMP;uid=sa;pwd=benilde;";

        // GET: Food
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddFood(FormCollection form)
        {
            string fn = form["FoodName"];
            string dc = form["Description"];
            string sp = form["SellingPrice"];

            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("INSERT INTO Food VALUES (@fn, @d, @sp)", con);
            com.Parameters.AddWithValue("@fn", fn);
            com.Parameters.AddWithValue("@d", dc);
            com.Parameters.AddWithValue("@sp", sp);
            com.ExecuteNonQuery();
            con.Close();

            return RedirectToAction("Index");
        }

        public ActionResult AddFood()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddFood2(Food obj)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("INSERT INTO Food VALUES (@fn, @d, @sp)", con);
            com.Parameters.AddWithValue("@fn", obj.FoodName);
            com.Parameters.AddWithValue("@d", obj.Description);
            com.Parameters.AddWithValue("@sp", obj.SellingPrice);
            com.ExecuteNonQuery();
            con.Close();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult EditFood(Food obj)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("UPDATE Food SET FoodName = @fn, Description = @d, SellingPrice = @sp WHERE FID = @fid", con);
            com.Parameters.AddWithValue("@fid", obj.FID);
            com.Parameters.AddWithValue("@fn", obj.FoodName);
            com.Parameters.AddWithValue("@d", obj.Description);
            com.Parameters.AddWithValue("@sp", obj.SellingPrice);
            com.ExecuteNonQuery();
            con.Close();

            return RedirectToAction("GetFoodRecord");
        }

        [HttpPost]
        public ActionResult DeleteFood(Food obj)
        {
            obj.DeleteFood();

            return RedirectToAction("GetFoodRecord");
        }

        [HttpGet]
        public ActionResult FoodDetails(Food obj)
        {
            Food f = obj.FoodDetails();

            return View(f);
        }

        public ActionResult GetFoodRecord()
        {
            Food f = new Food();
            List<Food> list = f.GetAllFood();

            return View(list);
        }
    }
}