﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace MPFinal.Models
{
    public class Cart
    {
        public int cartID { get; set; }
        public int UID { get; set; }
        public DateTime DatePurchased { get; set; }


        public string constring = "server=DESKTOP-0E62KFU\\SQLEXPRESS;database=FINALMP;uid=sa;pwd=benilde;";


        public void CartCheckOut()
        {
            SqlConnection con = new SqlConnection(constring);
            SqlTransaction trans;

            try
            {
                con.Open();
                trans = con.BeginTransaction();



            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}