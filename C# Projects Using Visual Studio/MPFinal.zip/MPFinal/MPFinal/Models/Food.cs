﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace MPFinal.Models
{
    public class Food
    {
        public int FID { get; set; }
        public string FoodName { get; set; }
        public string Description { get; set; }
        public decimal SellingPrice { get; set; }

        public string constring = "server=DESKTOP-0E62KFU\\SQLEXPRESS;database=FINALMP;uid=sa;pwd=benilde;";

        public void AddFood()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("INSERT INTO Food VALUES (@fn, @d, @sp)", con);
            com.Parameters.AddWithValue("@fn", FoodName);
            com.Parameters.AddWithValue("@d", Description);
            com.Parameters.AddWithValue("@sp", SellingPrice);
            com.ExecuteNonQuery();
            con.Close();

        }

        public void DeleteFood()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("DELETE FROM Food WHERE FID = @fid", con);
            com.Parameters.AddWithValue("@fid", FID);
            com.ExecuteNonQuery();
            con.Close();
        }

        public void EditFood()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("UPDATE Food SET FoodName = @fn, Description = @d, SellingPrice = @sp WHERE FID = @fid", con);
            com.Parameters.AddWithValue("@fid", FID);
            com.Parameters.AddWithValue("@fn", FoodName);
            com.Parameters.AddWithValue("@d", Description);
            com.Parameters.AddWithValue("@sp", SellingPrice);
            com.ExecuteNonQuery();
            con.Close();
        }

        public Food FoodDetails()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("SELECT * FROM Food WHERE FID = @fid", con);
            com.Parameters.AddWithValue("@fid", FID);
            SqlDataReader dr = com.ExecuteReader();
            Food f = new Food();
            if(dr.Read() == true)
            {
                f.FID = (int)dr[0];
                f.FoodName = dr[1].ToString();
                f.Description = dr[2].ToString();
                f.SellingPrice = (decimal)dr[3];
            }
            con.Close();

            return f;
        }

        public List<Food> GetAllFood()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();

            SqlCommand com = new SqlCommand("SELECT * FROM Food", con);
            SqlDataReader dr = com.ExecuteReader();
            List<Food> list = new List<Food>();
            while(dr.Read() == true)
            {
                Food f = new Food();
                f.FID = (int)dr[0];
                f.FoodName = dr[1].ToString();
                f.Description = dr[2].ToString();
                f.SellingPrice = (decimal)dr[3];

                list.Add(f);
            }
            con.Close();

            return list;
        }
    }
}