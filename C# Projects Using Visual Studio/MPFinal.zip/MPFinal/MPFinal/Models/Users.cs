﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace MPFinal.Models
{
    public class Users
    {
        public int UID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string UserLevel { get; set; }


        public string constring = "server=DESKTOP-0E62KFU\\SQLEXPRESS;database=FINALMP;uid=sa;pwd=benilde;";

        public List<Users> GetAll()
        {

            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users", con);
            SqlDataReader dr = com.ExecuteReader();

            List<Users> list = new List<Users>();

            while (dr.Read() == true)
            {

                Users u = new Users();

                u.Username = dr["Username"].ToString();

                u.UserLevel = dr["UserLevel"].ToString();

                list.Add(u);
            }

            dr.Close();
            con.Close();

            return list;
        }
    }
}