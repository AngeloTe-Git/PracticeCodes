﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyBookstore_TeAngelo.Controllers
{
    public class AuthorsController : Controller
    {
        public ActionResult Add()
        {
            return View();
        }
        // GET: Authors
        public ActionResult Index()
        {
            return View();
        }
    }
}