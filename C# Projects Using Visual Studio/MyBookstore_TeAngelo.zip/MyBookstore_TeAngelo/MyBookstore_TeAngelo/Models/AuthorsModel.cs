﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;

namespace MyBookstore_TeAngelo.Models
{
    public class AuthorsModel
    {
        [Key]
        public int ID { get; set; }


        [Display(Name ="Last Name")]
        [Required(ErrorMessage ="Type Last Name")]
        [MaxLength(40, ErrorMessage ="Too many words")]
        public string LN { get; set; }


        [Display(Name ="Fisrt Name")]
        [Required(ErrorMessage ="Pota Ka")]
        [MaxLength(20, ErrorMessage ="Too many words")]
        public string FN { get; set; }


        [Required(ErrorMessage ="Palaging naka phone, di alam number.")]
        [MaxLength(12, ErrorMessage = "Too many numbers")]
        public string Phone { get; set; }


        [MaxLength(40, ErrorMessage = "Too many words")]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }


        [MaxLength(20, ErrorMessage = "Too many words")]
        public string City { get; set; }


        [MaxLength(2, ErrorMessage = "Too many letters")]
        public string State { get; set; }


        [Display(Name = "Zip Code")]
        [MaxLength(5, ErrorMessage = "its just 5 letters")]
        public string Zip { get; set; }
    }
}